﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.WebControls;

namespace TheRoks.EnhancedUrlField.CodeBehind
{
    public class EnhancedUrlSelectorControl : BaseFieldControl
    {
        protected HyperLink testHyperLinkControl;
        protected AssetUrlSelector urlSelector;
        protected TextBox urlText;

        public override object Value
        {
            get
            {
                var URLValue = new SPFieldUrlValue();
                URLValue.Description = urlText.Text;
                URLValue.Url = urlSelector.AssetUrl;
                return URLValue;
            }
            set
            {
                var URLValue = new SPFieldUrlValue(value as string);
                urlText.Text = URLValue.Description;
                urlSelector.AssetUrl = URLValue.Url;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            // Set the value if this is a postback.
            if ((Page.IsPostBack) && (base.ControlMode == SPControlMode.Edit || base.ControlMode == SPControlMode.New))
            {
                var mcv = new SPFieldUrlValue();
                mcv.Url = urlSelector.AssetUrl;
                mcv.Description = urlText.Text;
                ListItemFieldValue = mcv;
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (urlSelector != null && testHyperLinkControl != null)
            {
                //Necessary to retrieve AssetUrl, otherwise textbox does not have clientId.
                string assetUrl = this.urlSelector.AssetUrl;
                testHyperLinkControl.NavigateUrl = "javascript:TestURL('" +
                                                   SPHttpUtility.EcmaScriptStringLiteralEncode(
                                                       urlSelector.AssetUrlClientID) + "')";
            }
        }

        protected override void CreateChildControls()
        {
            Controls.Add(new LiteralControl(GetResource("LabelWebAddressStart")));
            testHyperLinkControl = new HyperLink {Text = GetResource("LabelTestLink")};
            Controls.Add(testHyperLinkControl);
            Controls.Add(new LiteralControl(GetResource("LabelWebAddressEnd")));
            base.CreateChildControls();
            // Add the asset picker when in edit or new mode.
            if (base.ControlMode == SPControlMode.Edit || base.ControlMode == SPControlMode.New)
            {
                urlSelector = new AssetUrlSelector();
                Controls.Add(urlSelector);
                urlText = new TextBox();
                Controls.Add(new LiteralControl(GetResource("LabelDescription")));
                Controls.Add(urlText);
            }
        }

        public override void Validate()
        {
            if (ControlMode == SPControlMode.Display || !IsValid)
            {
                return;
            }
            base.Validate();
            if (Field.Required)
            {
                if ((Value == null))
                {
                    ErrorMessage = string.Format(GetResource("ErrorMessageValue"), Field.Title);
                    IsValid = false;
                }
                else if (Value != null)
                {
                    var mcv = (SPFieldUrlValue) Value;
                    if (mcv.Description.Length == 0)
                    {
                        ErrorMessage = string.Format(GetResource("ErrorMessageTitle"), Field.Title);
                        IsValid = false;
                        return;
                    }
                    if (mcv.Url.Length == 0)
                    {
                        ErrorMessage = string.Format(GetResource("ErrorMessageUrl"), Field.Title);
                        IsValid = false;
                    }
                }
            }
        }

        private static string GetResource(string key)
        {
            return SPUtility.GetLocalizedString(string.Format("$Resources:{0}", key),
                                                "TheRoks.EnhancedURLField",
                                                (uint) SPContext.Current.Web.Locale.LCID);
        }
    }
}