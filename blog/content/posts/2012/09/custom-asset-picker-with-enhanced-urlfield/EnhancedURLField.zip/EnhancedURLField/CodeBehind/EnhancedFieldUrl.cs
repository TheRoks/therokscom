﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace TheRoks.EnhancedUrlField.CodeBehind
{
    public class EnhancedFieldUrl : SPFieldUrl
    {
        public EnhancedFieldUrl(SPFieldCollection fields, string fieldName)
            : base(fields, fieldName)
        {
        }

        public EnhancedFieldUrl(SPFieldCollection fields, string typeName, string displayName)
            : base(fields, typeName, displayName)
        {
        }

        public override BaseFieldControl FieldRenderingControl
        {
            get
            {
                BaseFieldControl control = new EnhancedUrlSelectorControl();
                control.FieldName = base.InternalName;
                return control;
            }
        }

        public override object GetFieldValue(string value)
        {
            return value;
        }
    }
}